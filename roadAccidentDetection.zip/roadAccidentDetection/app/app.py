import pandas as pd
from flask import Flask, request, render_template, session, redirect, url_for, jsonify
import sqlite3
import joblib
import warnings
warnings.filterwarnings('ignore')

app = Flask(__name__)

# Configure SQLite database
DATABASE = 'database.db'

def create_db():
    conn = sqlite3.connect(DATABASE)
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS users 
                 (id INTEGER PRIMARY KEY AUTOINCREMENT, 
                  name TEXT,
                  email TEXT, 
                  mobile INTEGER, 
                  username TEXT UNIQUE, 
                  password TEXT)''')
    conn.commit()
    conn.close()

def insert_user(name, email, mobile, username, password):
    conn = sqlite3.connect(DATABASE)
    c = conn.cursor()
    sql_query = "INSERT INTO users (name, email, mobile, username, password) VALUES (?, ?, ?, ?, ?)"
    params = (name, email, mobile, username, password)
    print("SQL Query:", sql_query)
    print("Parameters:", params)
    c.execute(sql_query, params)
    conn.commit()
    conn.close()


def get_user(username):
    conn = sqlite3.connect(DATABASE)
    c = conn.cursor()
    c.execute("SELECT * FROM users WHERE username=?", (username,))
    user = c.fetchone()
    conn.close()
    return user

@app.route("/signup", methods=["GET", "POST"])
def signup():
    if request.method == "POST":
        name = request.form['name'] 
        email = request.form['email']
        mobile = request.form['mobile']
        username = request.form['username']
        password = request.form['password']
        
        if get_user(username):
            message = "User already exists!"
            return render_template('signup.html', message=message)
        insert_user(name, email, mobile, username, password)
        message = "Account successfully created"
        return render_template('signup.html', message=message)
    return render_template('signup.html')

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form['username']
        password = request.form['password']
        user = get_user(username)

        if user and user[5] == password:
            session['username'] = username
            # Check if the user is an admin
            # if username == 'admin':
            #     return redirect(url_for('index_admin'))
            # else:
            return redirect(url_for('index'))
        return render_template('login.html', message="Invalid username or password!")
    return render_template('login.html')


@app.route("/logout", methods=["POST"])
def logout():
    session.pop('username', None)
    return redirect(url_for('landing'))


@app.route("/admin", methods=["GET", "POST"])
def admin():
    if 'username' not in session or session['username'] != 'admin':
        return redirect(url_for('login'))

    if request.method == "POST":
        # Handle user removal
        username_to_remove = request.form.get('username')
        # Call a function to remove the user from the database
        remove_user(username_to_remove)
        return redirect(url_for('admin'))

    # Fetch all users from the database
    conn = sqlite3.connect(DATABASE)
    c = conn.cursor()
    c.execute("SELECT name, email, mobile, username FROM users")
    users = c.fetchall()
    conn.close()

    return render_template('admin.html', users=users)

@app.route("/")
def home():
    return render_template("landing.html")

@app.route("/landing")
def landing():
    return render_template("landing.html")

@app.route('/index')
def index():
    user = session['username']

    if user == 'admin':
        return render_template("index_admin.html")
    else:
        return render_template("index.html")

def remove_user(username):
    conn = sqlite3.connect(DATABASE)
    c = conn.cursor()
    c.execute("DELETE FROM users WHERE username=?", (username,))
    conn.commit()
    conn.close()

def edit_user(username, new_data):
    conn = sqlite3.connect(DATABASE)
    c = conn.cursor()
    c.execute("UPDATE users SET name=?, email=?, mobile=?, password=? WHERE username=?", 
              (new_data['name'], new_data['email'], new_data['mobile'], new_data['password'], username))
    conn.commit()
    conn.close()

def add_user(data):
    conn = sqlite3.connect(DATABASE)
    c = conn.cursor()
    c.execute("INSERT INTO users (name, email, mobile, username, password) VALUES (?, ?, ?, ?, ?)",
              (data['name'], data['email'], data['mobile'], data['username'], data['password']))
    conn.commit()
    conn.close()

@app.route('/update', methods=['POST'])
def update():

    if request.method == "POST":
        
        # Handle user editing
        data = request.json
        
        # Handle user editing
        username_to_edit = data.get('username')

        new_data = {
            'name': data.get('name'),
            'email': data.get('email'),
            'mobile': data.get('mobile'),
            'password': data.get('password')
        }

        print(new_data)

        edit_user(username_to_edit, new_data)

    # Fetch all users from the database
    conn = sqlite3.connect(DATABASE)
    c = conn.cursor()
    c.execute("SELECT name, email, mobile, username, password FROM users")
    users = c.fetchall()
    conn.close()

    return render_template('dashboard.html', users=users)

@app.route('/add', methods=['POST'])
def add():

    if request.method == "POST":
        
        # Handle user editing
        data = request.json

        new_data = {
            'name': data.get('name'),
            'email': data.get('email'),
            'mobile': data.get('mobile'),
            'password': data.get('password'),
            'username': data.get('username')
        }

        print(new_data)

        # Connect to the database
        conn = sqlite3.connect(DATABASE)
        c = conn.cursor()

        # Execute the query to fetch all usernames from the database
        c.execute("SELECT username FROM users")
        users = c.fetchall()

        # Check if the username exists in the database
        exists = any(new_data['username'] == user[0] for user in users)

        conn.close()

        if not exists:
            add_user(new_data)
        
        else:    
             # Fetch all users from the database
            conn = sqlite3.connect(DATABASE)
            c = conn.cursor()
            c.execute("SELECT name, email, mobile, username, password FROM users")
            users = c.fetchall()
            conn.close()

            return render_template('dashboard.html', users=users)    


    # Fetch all users from the database
    conn = sqlite3.connect(DATABASE)
    c = conn.cursor()
    c.execute("SELECT name, email, mobile, username, password FROM users")
    users = c.fetchall()
    conn.close()

    return render_template('dashboard.html', users=users)


@app.route('/check_username', methods=['POST'])
def check_username():
    # Get the username from the request data
    data = request.get_json()
    username = data.get('username', '')

    # Connect to the database
    conn = sqlite3.connect(DATABASE)
    c = conn.cursor()

    # Execute the query to fetch all usernames from the database
    c.execute("SELECT username FROM users")
    users = c.fetchall()

    # Check if the username exists in the database
    exists = any(username == user[0] for user in users)

    # Close the database connection
    conn.close()

    print(exists)

    # Return JSON response indicating whether the username exists
    return jsonify({'exists': exists})

@app.route("/dashboard", methods=["GET", "POST"])
def dashboard():

    
    if 'username' not in session or session['username'] != 'admin':
        return redirect(url_for('login'))
    
    if request.method == "POST":
        # Handle user removal
        username_to_remove = request.form.get('username')
        remove_user(username_to_remove)

        return redirect(url_for('dashboard'))

    # Fetch all users from the database
    conn = sqlite3.connect(DATABASE)
    c = conn.cursor()
    c.execute("SELECT name, email, mobile, username, password FROM users")
    users = c.fetchall()
    conn.close()

    return render_template('dashboard.html', users=users)

 # Load the saved label encoders
label_encoders = joblib.load('../models/label_encoders.pkl')

# Load models
model = joblib.load('../models/model.pkl')

severity_mapping = {0: 'Accidents with minor injuries, minimal property damage, or no injuries and minor damage to vehicles or property', 1: 'Accidents with moderate injuries, significant damage to vehicles or property, or requiring medical attention but not life-threatening', 2: 'Accidents with severe injuries, fatalities, extensive damage to vehicles or property, or involving hazardous materials or major road closures'}

@app.route("/roadaccident", methods=['GET', 'POST'])
def error():

    if request.method == "POST":

        # Get values from form
        age_band = request.form['age_band']
        sex = request.form['sex']
        educational_level = request.form['educational_level']
        vehicle_driver_relation = request.form['vehicle_driver_relation']
        driving_experience = request.form['driving_experience']
        lanes_or_medians = request.form['lanes_or_medians']
        types_of_junction = request.form['types_of_junction']
        road_surface_type = request.form['road_surface_type']
        light_conditions = request.form['light_conditions']
        weather_conditions = request.form['weather_conditions']
        type_of_collision = request.form['type_of_collision']
        vehicle_movement = request.form['vehicle_movement']
        pedestrian_movement = request.form['pedestrian_movement']
        cause_of_accident = request.form['cause_of_accident']
        
        # Create a DataFrame with the user input
        sample_data = {
            'Age_band_of_driver': [age_band],
            'Sex_of_driver': [sex],
            'Educational_level': [educational_level],
            'Vehicle_driver_relation': [vehicle_driver_relation],
            'Driving_experience': [driving_experience],
            'Lanes_or_Medians': [lanes_or_medians],
            'Types_of_Junction': [types_of_junction],
            'Road_surface_type': [road_surface_type],
            'Light_conditions': [light_conditions],
            'Weather_conditions': [weather_conditions],
            'Type_of_collision': [type_of_collision],
            'Vehicle_movement': [vehicle_movement],
            'Pedestrian_movement': [pedestrian_movement],
            'Cause_of_accident': [cause_of_accident]
        }

        print(sample_data)
        
        sample_data_df = pd.DataFrame(sample_data)

        for column, encoder in label_encoders.items():
            sample_data_df[column] = encoder.transform(sample_data_df[column])
        prediction = model.predict(sample_data_df)

        print(severity_mapping[prediction[0]])

        
        return render_template('roadaccident.html', prediction=severity_mapping[prediction[0]])
    return render_template("roadaccident.html")


if __name__ == "__main__":
    app.secret_key = 'fgxfhcgjvhkbl8674566ohihi987r6754'
    app.run(debug=True)
